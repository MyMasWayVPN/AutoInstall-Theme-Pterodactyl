@extends('templates/wrapper', [
    'css' => ['body' => 'bg-gray-900'],
])

@section('container')
    <div id="modal-portal"></div>
    <div id="app"></div>
@endsection
